const styles = theme => ({
    root: {},
    Typography_title: {
        marginBottom: theme.spacing.unit * 3,
    },
    CopyField: {
        marginBottom: theme.spacing.unit * 3,
        '&:last-child': {
            marginBottom: 0
        }
    }
});

export default styles;