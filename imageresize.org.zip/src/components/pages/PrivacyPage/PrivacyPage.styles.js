const styles = theme => ({
    root: {}
});

export default styles;