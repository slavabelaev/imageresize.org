const styles = theme => ({
    root: {},
    section: {
        marginBottom: theme.spacing.unit * 3
    }
});

export default styles;