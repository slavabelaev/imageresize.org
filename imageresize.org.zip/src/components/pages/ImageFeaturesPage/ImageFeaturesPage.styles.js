const styles = theme => ({
    root: {},
    header: {
        textAlign: 'center'
    },
    Grid_item: {
        marginBottom: theme.spacing.unit * 8
    }
});

export default styles;