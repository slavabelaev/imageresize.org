const styles = theme => ({
    root: {},
    header: {
        textAlign: 'center',
        marginBottom: theme.spacing.unit * 6
    }
});

export default styles;