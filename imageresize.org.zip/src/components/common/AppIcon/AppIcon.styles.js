const styles = theme => ({
    root: {
        display: 'inline-flex',
        backgroundSize: 'cover',
        transition: theme.transitions.create()
    }
});

export default styles;